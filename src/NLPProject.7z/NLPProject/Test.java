package NLPProject;

public class Test {
	public static void main(String args[]){
		String s = "anurag";
		int d = Integer.parseInt(s);
		System.out.println(d);
	}
}
