package NLPProject;

public class Twitter_Id_Rank {
	private String screen_name;
	private String twitter_id;
	private float twitter_rank;
	
	
	
	public String getScreen_name() {
		return screen_name;
	}
	public void setScreen_name(String screen_name) {
		this.screen_name = screen_name;
	}
	public String getTwitter_id() {
		return twitter_id;
	}
	public void setTwitter_id(String twitter_id) {
		this.twitter_id = twitter_id;
	}
	public float getTwitter_rank() {
		return twitter_rank;
	}
	public void setTwitter_rank(float twitter_rank) {
		this.twitter_rank = twitter_rank;
	}
	
	
	
}
