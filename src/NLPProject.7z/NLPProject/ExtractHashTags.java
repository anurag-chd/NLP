package NLPProject;

import java.io.*;
import java.util.Scanner;

public class ExtractHashTags {
	public static void main(String args[]) throws IOException{
		String output_file = "C:\\Users\\Anurag\\Desktop\\NLP\\celeb_hashtags.txt";
		String input_file = "C:\\Users\\Anurag\\Desktop\\NLP\\infochimps_dataset_11897_download_15372-tsv\\tokens_by_month\\disk1.tsv";
		Scanner s = new Scanner(new File(input_file));
		FileWriter fw = new FileWriter(new File(output_file));
		while(s.hasNextLine()){
			String temp = s.nextLine();
			String temp2[] = temp.split("\\s+");
			if(temp2[0].equals("hashtag")){
				fw.write(temp);
				fw.write("\n");
			}
			else{
				break;
			}
			
		}
		
	}
}
